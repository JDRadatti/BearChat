docker build -t auth-service .
docker run -p 80:80 auth-service